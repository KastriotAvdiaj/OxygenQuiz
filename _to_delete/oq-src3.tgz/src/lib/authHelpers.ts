// import Cookies from 'js-cookie';

export const encode = (obj: any) => {
  const btoa =
    typeof window === 'undefined'
      ? (str: string) => Buffer.from(str, 'binary').toString('base64')
      : window.btoa;
  return btoa(JSON.stringify(obj));
};

export const decode = (str: string) => {
  const atob =
    typeof window === 'undefined'
      ? (str: string) => Buffer.from(str, 'base64').toString('binary')
      : window.atob;
  return JSON.parse(atob(str));
};

export const hash = (str: string) => {
  let hash = 5381,
    i = str.length;

  while (i) {
    hash = (hash * 33) ^ str.charCodeAt(--i);
  }
  return String(hash >>> 0);
};


const omit = <T extends object>(obj: T, keys: string[]): T => {
  const result = {} as T;
  for (const key in obj) {
    if (!keys.includes(key)) {
      result[key] = obj[key];
    }
  }

  return result;
};

export const sanitizeUser = <O extends object>(user: O) =>
  omit<O>(user, ['password', 'iat']);

export const AUTH_COOKIE = `quiz_app_token`;

// export function requireAuth(cookies: Record<string, string>) {
//   try {
//     const encodedToken = cookies[AUTH_COOKIE] || Cookies.get(AUTH_COOKIE);
//     if (!encodedToken) {
//       return { error: 'Unauthorized', user: null };
//     }
//     const decodedToken = decode(encodedToken) as { id: string };

    // const user = db.user.findFirst({
     //   where: {
   //     id: {
   //       equals: decodedToken.id,
    //     },
    //   },
    // })

//     if (!user) {
//       return { error: 'Unauthorized', user: null };
//     }

//     return { user: sanitizeUser(user) };
//   } catch (err: any) {
//     return { error: 'Unauthorized', user: null };
//   }
// }

export function requireAdmin(user: any) {
  const roles: string[] = user?.roles ?? [];
  if (!roles.includes('Admin') && !roles.includes('SuperAdmin')) {
    throw Error('Unauthorized');
  }
}
