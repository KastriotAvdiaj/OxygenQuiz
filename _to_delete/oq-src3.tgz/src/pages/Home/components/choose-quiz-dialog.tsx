// import { ChooseQuizDialog } from "./quiz-conf    irmation-dialog";
import { Link, useNavigation } from "react-router-dom";
import { useState } from "react";
import { LiftedButton } from "@/common/LiftedButton";

export const ChooseQuiz = () => {
  const navigation = useNavigation();
  const [isNavigating, setIsNavigating] = useState(false);

  // Check if we're navigating to a quiz route
  const isLoading =
    navigation.state === "loading" &&
    navigation.location?.pathname?.includes("/choose-quiz/");

  const handleQuizNavigation = () => {
    setIsNavigating(true);
  };

  return (
    <Link to="/choose-mode">
      {/* Fluid CTA: fixed text-5xl dwarfed phone screens (docs/RESPONSIVE.md) */}
      <LiftedButton
        // variant={"fancy"}
        outerClassName={`rounded-none p-2`}
        className={`text-xl sm:text-3xl md:text-4xl lg:text-5xl px-5 py-2 sm:p-4 rounded-none -bottom-0 -right-0 inset-x-[0]`}
        disabled={isLoading || isNavigating}
        onClick={handleQuizNavigation}
      >
        Explore
      </LiftedButton>
    </Link>
  );
};
