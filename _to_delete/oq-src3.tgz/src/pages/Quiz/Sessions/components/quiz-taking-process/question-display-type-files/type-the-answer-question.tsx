import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Input } from "@/components/ui/form";
import { CheckCircle, XCircle } from "lucide-react";
import type { InstantFeedbackAnswerResult } from "../../../../../../types/quiz-session-types";
import { QuizSubmitButton } from "../quiz-submit-button";
import { ANSWER_SELECTED_BORDER } from "../answer-colors";

export interface TypeTheAnswerQuestionProps {
  onSubmit: (selectedOptionId: number | null, submittedAnswer?: string) => void;
  isSubmitting: boolean;
  instantFeedback?: boolean;
  answerResult?: InstantFeedbackAnswerResult | null;
  isTimedOut?: boolean;
  onSelectionChange?: (optionId: number | null, textAnswer?: string) => void;
}

export function TypeTheAnswerQuestion({
  onSubmit,
  isSubmitting,
  instantFeedback = false,
  answerResult = null,
  isTimedOut = false,
  onSelectionChange,
}: TypeTheAnswerQuestionProps) {
  const [answer, setAnswer] = useState<string>("");

  // Sync current text to parent ref
  useEffect(() => {
    const trimmed = answer.trim();
    onSelectionChange?.(null, trimmed || undefined);
  }, [answer, onSelectionChange]);

  const handleSubmit = () => {
    const trimmedAnswer = answer.trim();
    onSubmit(null, trimmedAnswer);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (
      e.key === "Enter" &&
      answer.trim() &&
      !isSubmitting &&
      !answerResult &&
      !isTimedOut
    ) {
      handleSubmit();
    }
  };

  const isCorrect = answerResult?.status === "Correct";
  const isAnswered = instantFeedback && !!answerResult;
  const isDisabled = isAnswered || isTimedOut;

  return (
    <div className="space-y-4 sm:space-y-6">
      <div className="flex flex-col items-center space-y-4 sm:space-y-6">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="w-full max-w-lg relative">
          <Input
            type="text"
            value={answer}
            onChange={(e) => setAnswer(e.target.value)}
            onKeyUp={handleKeyPress}
            placeholder="Type your answer here..."
            className={`
              h-12 sm:h-16 text-lg sm:text-xl text-center border-3 rounded-xl transition-all duration-300
              ${isDisabled ? "cursor-not-allowed" : ""}
              ${
                instantFeedback && answerResult
                  ? isCorrect
                    ? "border-green-500 bg-green-50 dark:bg-green-900/20 text-green-700 dark:text-green-300"
                    : "border-red-500 bg-red-50 dark:bg-red-900/20 text-red-700 dark:text-red-300"
                  : ""
              }
            `}
            style={{
              borderColor:
                instantFeedback && answerResult
                  ? isCorrect
                    ? "#10b981"
                    : "#ef4444"
                  : answer.trim()
                  ? ANSWER_SELECTED_BORDER
                  : undefined,
              backgroundColor:
                instantFeedback && answerResult
                  ? isCorrect
                    ? "#10b98115"
                    : "#ef444415"
                  : undefined,
              borderWidth: "3px",
            }}
            disabled={isDisabled}
            autoFocus={!isDisabled}
          />

          {/* Feedback icon inside input */}
          {instantFeedback && answerResult && (
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              className="absolute right-4 top-1/2 -translate-y-1/2">
              {isCorrect ? (
                <CheckCircle className="w-5 h-5 sm:w-6 sm:h-6 text-green-600" />
              ) : (
                <XCircle className="w-5 h-5 sm:w-6 sm:h-6 text-red-600" />
              )}
            </motion.div>
          )}
        </motion.div>

        {/* Show correct answer if incorrect */}
        {instantFeedback &&
          answerResult &&
          !isCorrect &&
          answerResult.correctAnswer && (
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="text-center p-3 sm:p-4 rounded-lg bg-gray-100 dark:bg-gray-800 border-2 border-gray-200 dark:border-gray-700">
              <p className="text-xs sm:text-sm text-gray-600 dark:text-gray-400 mb-1">
                Correct answer:
              </p>
              <p className="text-base sm:text-lg font-semibold text-green-700 dark:text-green-300">
                {answerResult.correctAnswer}
              </p>
            </motion.div>
          )}

        {!answerResult && !isTimedOut && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.4 }}
            className="text-xs sm:text-sm text-gray-500 text-center">
            Press Enter or click Submit to answer
          </motion.div>
        )}
      </div>

      {/* Submit button (shared across all question types) */}
      <QuizSubmitButton
        onSubmit={handleSubmit}
        canSubmit={!!answer.trim()}
        isSubmitting={isSubmitting}
        answered={isAnswered}
        isTimedOut={isTimedOut}
        motionDelay={0.3}
      />
    </div>
  );
}
