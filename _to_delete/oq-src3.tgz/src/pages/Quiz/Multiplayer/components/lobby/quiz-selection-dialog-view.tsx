import { useCallback, useRef } from "react";
import { Badge } from "@/components/ui/badge";
import { LoadingWave } from "@/components/ui";
import { PaginationControls } from "@/components/ui/pagination-control";
import { HelpCircle, Clock, Check, ArchiveX, ChevronDown, ListFilter } from "lucide-react";
import type { QuizSummaryDTO } from "@/types/quiz-types";
import type {
  QuestionCategory,
  QuestionDifficulty,
  QuestionLanguage,
} from "@/types/question-types";
import type { Pagination } from "@/types/common-types";
import { secondsToMinutes } from "@/pages/Quiz/components/quiz-duration";
import type { SelectedQuiz } from "../../hooks/use-lobby-connection";
import { cn } from "@/utils/cn";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import {
  QuizToolbar,
} from "@/pages/Quiz/components/quiz-header";
import {
  QuizFilterPanel,
  type QuizFacetKey,
  type QuizFilterSelections,
} from "@/pages/Quiz/components/quiz-filters";
import { motion, AnimatePresence } from "framer-motion";

export interface QuizSelectionDialogViewProps {
  isOpen: boolean;
  onClose: () => void;
  selectedQuiz: SelectedQuiz | null;

  searchQuery: string;
  onSearchChange: (value: string) => void;
  resultCount: number;
  onClearFilters: () => void;

  filtersOpen: boolean;
  onFiltersOpenChange: (open: boolean) => void;
  facetCount: number;
  categories: QuestionCategory[];
  difficulties: QuestionDifficulty[];
  languages: QuestionLanguage[];
  selections: QuizFilterSelections;
  onToggleFacet: (facet: QuizFacetKey, id: number) => void;
  onClearFacets: () => void;

  isLoading: boolean;
  quizzes: QuizSummaryDTO[];
  onSelectQuiz: (quiz: QuizSummaryDTO) => void;

  pagination?: Pagination;
  onPageChange: (page: number) => void;
}

/**
 * Presentational half of QuizSelectionDialog: the search/filter toolbar, quiz grid, and
 * pagination. Split out of the hook-wired component (useSearchQuizzes + 3 facet-data queries)
 * so it can be previewed in Storybook with no backend — same pattern as MultiplayerGame /
 * QuizInterface.
 */
export const QuizSelectionDialogView = ({
  isOpen,
  onClose,
  selectedQuiz,
  searchQuery,
  onSearchChange,
  resultCount,
  onClearFilters,
  filtersOpen,
  onFiltersOpenChange,
  facetCount,
  categories,
  difficulties,
  languages,
  selections,
  onToggleFacet,
  onClearFacets,
  isLoading,
  quizzes,
  onSelectQuiz,
  pagination,
  onPageChange,
}: QuizSelectionDialogViewProps) => {
  const scrollRef = useRef<HTMLDivElement>(null);

  const hasActiveFilters = Boolean(searchQuery) || facetCount > 0;

  const handlePageChange = useCallback(
    (newPage: number) => {
      scrollRef.current?.scrollTo({ top: 0 });
      onPageChange(newPage);
    },
    [onPageChange]
  );

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      {/* Wider on large screens (the quiz grid gains a third column); still
          near full-width on mobile and capped by the viewport. */}
      <DialogContent className="w-[calc(100vw-2rem)] sm:max-w-2xl lg:max-w-4xl xl:max-w-5xl max-h-[90vh] flex flex-col gap-0 p-0 overflow-hidden rounded-lg">
        <div className="p-4 sm:p-6 pb-2 space-y-4 flex flex-col shrink-0">
          <DialogHeader className="space-y-2">
            <div className="flex items-center justify-between">
              <DialogTitle className="text-xl sm:text-2xl font-bold font-quiz tracking-wider text-foreground">
                Select a Quiz
              </DialogTitle>
              <Badge variant="secondary" className="text-[10px] font-medium px-2 py-0.5 border border-primary/20 bg-primary/5 text-primary">
                Public Only
              </Badge>
            </div>
            <DialogDescription className="text-sm text-muted-foreground">
              Choose a quiz to host for this multiplayer lobby.
            </DialogDescription>
          </DialogHeader>

          {/* Toolbar + collapsible facet panel */}
          <Collapsible open={filtersOpen} onOpenChange={onFiltersOpenChange}>
            <QuizToolbar
              searchQuery={searchQuery}
              onSearchChange={onSearchChange}
              resultCount={resultCount}
              activeFilterCount={(searchQuery ? 1 : 0) + facetCount}
              onClearFilters={onClearFilters}
              filterAction={
                <CollapsibleTrigger asChild>
                  <button
                    type="button"
                    className="inline-flex items-center gap-1.5 h-9 px-3 rounded-lg border border-border bg-background text-sm shadow-sm transition-colors duration-150 hover:border-foreground/25 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary/30 data-[state=open]:border-primary/50"
                  >
                    <ListFilter className="h-4 w-4 text-muted-foreground" />
                    Filters
                    {facetCount > 0 && (
                      <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1.5 text-[11px] font-bold text-white tabular-nums">
                        {facetCount}
                      </span>
                    )}
                    <ChevronDown
                      className={cn(
                        "h-3.5 w-3.5 text-muted-foreground transition-transform duration-200",
                        filtersOpen && "rotate-180"
                      )}
                    />
                  </button>
                </CollapsibleTrigger>
              }
            />
            <CollapsibleContent>
              {/* Inset surface — the dialog itself is bg-muted, so bg-background
                  reads as a clearly recessed panel in both themes. */}
              <div className="mt-3 rounded-xl border border-border bg-background px-3 py-2.5">
                <QuizFilterPanel
                  variant="compact"
                  categories={categories}
                  difficulties={difficulties}
                  languages={languages}
                  selections={selections}
                  onToggle={onToggleFacet}
                  onClearAll={onClearFacets}
                  activeCount={facetCount}
                />
              </div>
            </CollapsibleContent>
          </Collapsible>
        </div>

        {/* Scrollable quiz list */}
        <div
          ref={scrollRef}
          className="flex-1 overflow-y-auto p-4 sm:p-6 pt-0 min-h-[300px] scrollbar-thin"
        >
          {isLoading ? (
            <div className="flex h-40 flex-col items-center justify-center">
              <LoadingWave size="md" />
            </div>
          ) : quizzes.length === 0 ? (
            <motion.div
              className="flex h-40 flex-col items-center justify-center gap-3 text-sm sm:text-base text-muted-foreground"
              initial={{ opacity: 0, scale: 0.95 }}
              animate={{ opacity: 1, scale: 1 }}
            >
              <ArchiveX className="h-8 w-8 sm:h-10 sm:w-10 opacity-50" />
              <span>No quizzes found</span>
              {hasActiveFilters && (
                <button
                  onClick={onClearFilters}
                  className="text-xs text-primary hover:underline font-medium"
                >
                  Clear filters
                </button>
              )}
            </motion.div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 sm:gap-4">
              <AnimatePresence mode="popLayout">
                {quizzes.map((quiz) => {
                  const isSelected = selectedQuiz?.id === quiz.id.toString();
                  const primaryColor = (() => {
                    try {
                      return quiz.colorPaletteJson
                        ? (JSON.parse(quiz.colorPaletteJson) as string[])[0]
                        : "#6366f1";
                    } catch {
                      return "#6366f1";
                    }
                  })();

                  return (
                    <motion.button
                      layout
                      initial={{ opacity: 0, scale: 0.95 }}
                      animate={{ opacity: 1, scale: 1 }}
                      exit={{ opacity: 0, scale: 0.95 }}
                      transition={{ duration: 0.2 }}
                      key={quiz.id}
                      onClick={() => onSelectQuiz(quiz)}
                      className={`group relative text-left p-3 sm:p-4 rounded-xl border-2 transition-all duration-200 overflow-hidden ${
                        isSelected
                          ? "border-primary shadow-sm"
                          : "border-border/60 hover:border-primary/50 bg-background hover:shadow-sm"
                      }`}
                    >
                      {/* Selection background / hover effect */}
                      <div
                        className={`absolute inset-0 transition-opacity duration-200 ${
                          isSelected ? "opacity-10" : "opacity-0 group-hover:opacity-5"
                        }`}
                        style={{ backgroundColor: primaryColor }}
                      />

                      <div className="relative flex items-start justify-between gap-3">
                        <div className="flex-1 min-w-0 space-y-2">
                          {/* Title block */}
                          <div className="flex items-center justify-between gap-2">
                            <span className="text-sm sm:text-base font-bold font-quiz tracking-wider text-foreground line-clamp-1">
                              {quiz.title}
                            </span>
                          </div>

                          {/* Top badge */}
                          <div className="flex items-center gap-2">
                             <span
                              className="px-[6px] py-[2px] rounded text-[9px] font-bold uppercase tracking-wider border"
                              style={{
                                backgroundColor: `${primaryColor}10`,
                                color: primaryColor,
                                borderColor: `${primaryColor}30`,
                              }}
                            >
                              {quiz.category || "Uncategorized"}
                            </span>
                             <span className="text-[10px] sm:text-xs text-muted-foreground font-medium truncate">
                              by {quiz.user}
                            </span>
                          </div>

                          {/* Stats block */}
                          <div className="flex items-center gap-3 text-[10px] sm:text-xs text-muted-foreground pt-1">
                            <span className="flex items-center gap-1">
                              <HelpCircle className="h-3.5 w-3.5" style={{ color: primaryColor }} />
                              <span className="font-medium text-foreground">{quiz.questionCount}</span> q
                            </span>
                            {quiz.timeLimitInSeconds > 0 && (
                              <span className="flex items-center gap-1">
                                <Clock className="h-3.5 w-3.5" style={{ color: primaryColor }} />
                                <span className="font-medium text-foreground">{secondsToMinutes(quiz.timeLimitInSeconds)}</span>
                              </span>
                            )}
                          </div>
                        </div>

                        {isSelected ? (
                          <div className="flex-shrink-0 mt-1 p-1.5 rounded-full bg-primary text-white shadow-sm">
                            <Check className="h-3.5 w-3.5" />
                          </div>
                        ) : (
                          <div
                            className="flex-shrink-0 mt-1 p-1.5 rounded-full border-2 border-transparent transition-colors duration-200 group-hover:border-primary/20"
                          />
                        )}
                      </div>
                    </motion.button>
                  );
                })}
              </AnimatePresence>
            </div>
          )}
        </div>

        {pagination && pagination.totalPages > 1 && (
          <div className="border-t border-border/60 px-4 sm:px-6 py-2.5">
            <PaginationControls
              pagination={pagination}
              onPageChange={handlePageChange}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
