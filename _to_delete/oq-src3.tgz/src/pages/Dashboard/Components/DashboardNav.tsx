import { useMemo } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { PanelLeftClose, PanelLeftOpen } from "lucide-react";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import type { DashboardNavItem } from "./dashboardNavConfig";
import { ROLES, useAuthorization } from "@/lib/authorization";
import { cn } from "@/utils/cn";

type DashboardNavProps = {
  navItems: DashboardNavItem[];
  setActivePage: (page: string) => void;
  activePage: string;
  isCollapsed?: boolean;
  setIsCollapsed?: (isCollapsed: boolean) => void;
};

type NavGroup = { name: string; items: DashboardNavItem[] };

const activePillTransition = {
  type: "spring" as const,
  stiffness: 520,
  damping: 42,
};

const labelTransition = { duration: 0.18, ease: "easeOut" as const };

/**
 * A single navigation row. The active state is drawn with two shared-layout
 * elements (a background pill + a left accent bar) so it glides between items
 * when the selection changes.
 */
const NavItem = ({
  item,
  isActive,
  isCollapsed,
  onSelect,
}: {
  item: DashboardNavItem;
  isActive: boolean;
  isCollapsed: boolean;
  onSelect: () => void;
}) => {
  const Icon = item.icon;

  const button = (
    <button
      type="button"
      onClick={onSelect}
      aria-current={isActive ? "page" : undefined}
      className={cn(
        "group relative flex w-full items-center rounded-lg py-2 text-sm outline-none transition-colors",
        "focus-visible:ring-1 focus-visible:ring-ring",
        isCollapsed ? "justify-center px-0" : "px-3",
        !isActive && "hover:bg-muted/60",
      )}
    >
      {isActive && (
        <>
          <motion.span
            layoutId="dashboard-nav-pill"
            transition={activePillTransition}
            className="absolute inset-0 rounded-lg bg-muted"
          />
          <motion.span
            layoutId="dashboard-nav-bar"
            transition={activePillTransition}
            className="absolute left-0 top-1.5 bottom-1.5 w-[3px] rounded-full bg-primary"
          />
        </>
      )}

      <Icon
        size={18}
        strokeWidth={1.75}
        className={cn(
          "relative z-10 h-[18px] w-[18px] shrink-0 transition-colors",
          isActive
            ? "text-primary"
            : "text-muted-foreground group-hover:text-foreground",
        )}
      />

      <AnimatePresence initial={false}>
        {!isCollapsed && (
          <motion.span
            key="label"
            initial={{ opacity: 0, width: 0 }}
            animate={{ opacity: 1, width: "auto" }}
            exit={{ opacity: 0, width: 0 }}
            transition={labelTransition}
            className={cn(
              "relative z-10 ml-3 overflow-hidden whitespace-nowrap text-[13px] font-medium",
              isActive
                ? "text-foreground"
                : "text-muted-foreground group-hover:text-foreground",
            )}
          >
            {item.label}
          </motion.span>
        )}
      </AnimatePresence>
    </button>
  );

  if (!isCollapsed) return button;

  return (
    <Tooltip>
      <TooltipTrigger asChild>{button}</TooltipTrigger>
      <TooltipContent side="right" className="font-medium bg-background">
        {item.label}
      </TooltipContent>
    </Tooltip>
  );
};

export const DashboardNav: React.FC<DashboardNavProps> = ({
  navItems,
  setActivePage,
  activePage,
  isCollapsed = false,
  setIsCollapsed = () => {},
}) => {
  const { checkAccess } = useAuthorization();

  // Filter by role first, then bucket into groups (preserving first-seen order)
  // so a fully role-gated section never leaves an orphaned label behind.
  const groups = useMemo<NavGroup[]>(() => {
    const visible = navItems.filter((item) =>
      checkAccess({ allowedRoles: (item.roles ?? []) as ROLES[] }),
    );

    const order: string[] = [];
    const byName = new Map<string, DashboardNavItem[]>();

    for (const item of visible) {
      const name = item.group ?? "";
      if (!byName.has(name)) {
        byName.set(name, []);
        order.push(name);
      }
      byName.get(name)!.push(item);
    }

    return order.map((name) => ({ name, items: byName.get(name)! }));
  }, [navItems, checkAccess]);

  const toggleCollapse = () => setIsCollapsed(!isCollapsed);

  return (
    <TooltipProvider delayDuration={0}>
      <nav
        aria-label="Dashboard"
        className="flex h-full flex-col bg-background px-2 py-4"
      >
        <div className="flex-1 space-y-4 overflow-y-auto overflow-x-hidden">
          {groups.map((group, groupIndex) => (
            <div key={group.name || `section-${groupIndex}`}>
              {group.name &&
                (isCollapsed ? (
                  groupIndex > 0 && <div className="mx-2 mb-2 h-px bg-border" />
                ) : (
                  <p className="mb-1.5 px-3 text-[11px] font-semibold uppercase tracking-wider text-muted-foreground/70">
                    {group.name}
                  </p>
                ))}

              <div className="space-y-0.5">
                {group.items.map((item) => (
                  <NavItem
                    key={item.id}
                    item={item}
                    isActive={activePage === item.id}
                    isCollapsed={isCollapsed}
                    onSelect={() => setActivePage(item.id)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-3 border-t border-border pt-2">
          <button
            type="button"
            onClick={toggleCollapse}
            aria-label={isCollapsed ? "Expand sidebar" : "Collapse sidebar"}
            className={cn(
              "group flex w-full items-center rounded-lg py-2 text-sm text-muted-foreground transition-colors hover:bg-muted/60 hover:text-foreground",
              isCollapsed ? "justify-center px-0" : "px-3",
            )}
          >
            {isCollapsed ? (
              <PanelLeftOpen size={18} className="shrink-0" />
            ) : (
              <PanelLeftClose size={18} className="shrink-0" />
            )}
            <AnimatePresence initial={false}>
              {!isCollapsed && (
                <motion.span
                  key="collapse-label"
                  initial={{ opacity: 0, width: 0 }}
                  animate={{ opacity: 1, width: "auto" }}
                  exit={{ opacity: 0, width: 0 }}
                  transition={labelTransition}
                  className="ml-3 overflow-hidden whitespace-nowrap text-[13px] font-medium"
                >
                  Collapse
                </motion.span>
              )}
            </AnimatePresence>
          </button>
        </div>
      </nav>
    </TooltipProvider>
  );
};

export default DashboardNav;
