import { useMutation, useQueryClient } from "@tanstack/react-query";
import { z } from "zod";
import { apiService } from "@/lib/Api-client";
import { MutationConfig } from "@/lib/React-query";
import { UnspecifiedIds } from "../../../Quiz/components/Create-Quiz-Form/constants";
import { TypeTheAnswerQuestion } from "@/types/question-types";
import { myQuestionKeys, questionKeys } from "@/lib/query-keys";
import {
  MAX_ACCEPTABLE_ANSWERS,
  MAX_ACCEPTABLE_ANSWERS_MESSAGE,
} from "./constants";

export const createTypeTheAnswerQuestionInputSchema = z.object({
  text: z.string().min(1, "Question is required"),
  // Difficulty is the only classification that may stay Unspecified — it's rated later.
  // Category and language are required: a question stored as Unspecified is unfilterable and
  // undiscoverable in the bank. The API enforces the same rule by name, so this is the fast
  // feedback path, not the gate. See docs/quiz/quiz-question-classification.md.
  difficultyId: z
    .number()
    .int()
    .positive("Choose a difficulty")
    .optional()
    .default(UnspecifiedIds.difficultyId),
  categoryId: z.number().int().positive("Choose a category"),
  languageId: z.number().int().positive("Choose a language"),
  visibility: z.string().optional(),
  correctAnswer: z.string().min(1, "Correct answer is required"),
  isCaseSensitive: z.boolean().default(false),
  allowPartialMatch: z.boolean().default(false),
  imageUrl: z.string().optional(),
  acceptableAnswers: z
    .array(
      z.object({
        value: z
          .string()
          .min(1, "Additional acceptable answer cannot be empty"),
      })
    )
    .max(MAX_ACCEPTABLE_ANSWERS, MAX_ACCEPTABLE_ANSWERS_MESSAGE)
    .default([]),
});

const transformFormData = (data: CreateTypeTheAnswerQuestionInput) => {
  const transformedData = {
    ...data,
    acceptableAnswers: data.acceptableAnswers
      ? data.acceptableAnswers.map((item) => item.value)
      : [],
  };

  return transformedData;
};

export type CreateTypeTheAnswerQuestionInput = z.infer<
  typeof createTypeTheAnswerQuestionInputSchema
>;

export const createTypeTheAnswerQuestion = ({
  data,
}: {
  data: CreateTypeTheAnswerQuestionInput;
}): Promise<TypeTheAnswerQuestion> => {
  return (
    console.log("data", data),
    apiService.post("/questions/typeTheAnswer", transformFormData(data))
  );
};

type UseCreateTypeTheAnswerQuestionOptions = {
  mutationConfig?: MutationConfig<typeof createTypeTheAnswerQuestion>;
};

export const useCreateTypeTheAnswerQuestion = ({
  mutationConfig,
}: UseCreateTypeTheAnswerQuestionOptions = {}) => {
  const queryClient = useQueryClient();

  const { onSuccess, onError, ...restConfig } = mutationConfig || {};

  return useMutation({
    mutationFn: createTypeTheAnswerQuestion,
    onSuccess: (...args) => {
      // Broad roots cover admin search, typed search, and the user dashboard.
      queryClient.invalidateQueries({ queryKey: questionKeys.all });
      queryClient.invalidateQueries({ queryKey: myQuestionKeys.all });
      onSuccess?.(...args);
    },
    onError: (error, variables, onMutateResult, context) => {
      console.error("Error creating type-the-answer question:", error);
      onError?.(error, variables, onMutateResult, context);
    },
    ...restConfig,
  });
};
