import { NotFoundContent } from "./Not-Found-Content";
import { getErrorFontClass } from "../errorFontZone";

export const NotFoundRoute = () => {
  return (
    <div
      className={`${getErrorFontClass()} app-shell-viewport flex items-center justify-center bg-background p-6 sm:p-8`}>
      <NotFoundContent
        message="Oops! The page you're looking for doesn't exist. It might have been moved or deleted."
        linkText="Go back to Home Page"
        linkTo="/"
      />
    </div>
  );
};
