import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { ReactQueryDevtools } from "@tanstack/react-query-devtools";
import * as React from "react";
import { ErrorBoundary } from "react-error-boundary";
import { HelmetProvider } from "react-helmet-async";
import { ThemeProvider } from "./components/ui/theme-provider";
import { LoadingWave } from "./components/ui/loading-wave";
import { MainErrorFallback } from "./pages/UtilityPages/Error/Main-Error-Boundary";
import { AuthLoader } from "./lib/Auth";
import { queryConfig } from "./lib/React-query";
import { Notifications } from "./common/Notifications";
import { SettingsApplier } from "./common/SettingsApplier";
import { MultiplayerProvider } from "./context/multiplayer-context";
import { AudioProvider } from "./lib/audio";

type AppProviderProps = {
  children: React.ReactNode;
};

export const AppProvider = ({ children }: AppProviderProps) => {
  const [queryClient] = React.useState(
    () =>
      new QueryClient({
        defaultOptions: queryConfig,
      })
  );

  return (
    <React.Suspense
      fallback={
        // app-shell-viewport, not h-screen: sizes to the real visible viewport
        // on mobile (docs/RESPONSIVE.md)
        <div className="app-shell-viewport flex w-full items-center justify-center bg-background">
          <LoadingWave size="xl" />
        </div>
      }
    >
      <ErrorBoundary FallbackComponent={MainErrorFallback}>
        <HelmetProvider>
          <QueryClientProvider client={queryClient}>
            <ReactQueryDevtools initialIsOpen={false} />
            <ThemeProvider defaultTheme="dark" storageKey="vite-ui-theme">
              <Notifications />
              <AuthLoader
                renderLoading={() => (
                  <div className="app-shell-viewport flex w-full items-center justify-center bg-background">
                    <LoadingWave size="xl" />
                  </div>
                )}
              >
                <SettingsApplier />
                <AudioProvider>
                  <MultiplayerProvider>
                    {children}
                  </MultiplayerProvider>
                </AudioProvider>
              </AuthLoader>
            </ThemeProvider>
          </QueryClientProvider>
        </HelmetProvider>
      </ErrorBoundary>
    </React.Suspense>
  );
};
