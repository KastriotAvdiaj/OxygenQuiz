import { useEffect, useState } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { DashboardHeader } from "@/pages/Dashboard/Components/DashboardHeader";
import { DashboardNav } from "@/pages/Dashboard/Components/DashboardNav";
import type { DashboardNavItem } from "@/pages/Dashboard/Components/dashboardNavConfig";
import { cn } from "@/utils/cn";

interface DashboardLayoutProps {
  children: React.ReactNode;
  basePath: string; // "/dashboard" | "/my-dashboard"
  navItems: DashboardNavItem[];
  fullWidthPaths?: string[]; // paths that hide the nav (e.g. quiz creator)
}

export const DashboardLayout = ({
  children,
  basePath,
  navItems,
  fullWidthPaths = [],
}: DashboardLayoutProps) => {
  const navigate = useNavigate();
  const location = useLocation();
  const [isNavCollapsed, setIsNavCollapsed] = useState(false);

  // Responsive: collapse to an icon rail on narrower viewports, expand back on
  // wide ones. Users can still toggle manually within a breakpoint.
  useEffect(() => {
    const mq = window.matchMedia("(max-width: 1024px)");
    const apply = (matches: boolean) => setIsNavCollapsed(matches);
    apply(mq.matches);
    const handler = (e: MediaQueryListEvent) => apply(e.matches);
    mq.addEventListener("change", handler);
    return () => mq.removeEventListener("change", handler);
  }, []);

  const setActivePage = (page: string) => {
    navigate(`${basePath}/${page}`);
  };

  const activePage = location.pathname.split("/").pop() || "";
  // Exact match, or prefix match for parameterised paths (e.g. .../edit-quiz/:quizId).
  const isFullWidth = fullWidthPaths.some(
    (path) =>
      location.pathname === path || location.pathname.startsWith(`${path}/`)
  );

  if (isFullWidth) {
    // Show header but no nav
    return (
      <div className="text-foreground h-screen flex flex-col">
        <header className="flex-none">
          <DashboardHeader />
        </header>

        <main className="flex-1 overflow-y-auto bg-muted p-4 sm:p-6 lg:p-8">{children}</main>
      </div>
    );
  }

  return (
    <div className="text-foreground h-screen flex flex-col">
      <header className="flex-none">
        <DashboardHeader />
      </header>

      <div className="flex flex-1 overflow-hidden">
        <aside
          className={cn(
            "bg-background relative flex-none overflow-hidden border-r border-border transition-[width] duration-300 ease-in-out",
            isNavCollapsed ? "w-[76px]" : "w-64"
          )}
          aria-label="Dashboard navigation">
          <DashboardNav
            navItems={navItems}
            setActivePage={setActivePage}
            activePage={activePage}
            isCollapsed={isNavCollapsed}
            setIsCollapsed={setIsNavCollapsed}
          />
        </aside>

        <main className="flex-1 overflow-y-auto bg-muted p-10">{children}</main>
      </div>
    </div>
  );
};

export default DashboardLayout;
