﻿using QuizAPI.DTOs.Question;
using QuizAPI.Models.Quiz;
using QuizAPI.Models;
using System.Text.Json.Serialization;

namespace QuizAPI.DTOs.Quiz
{
        public enum LiveQuizStatus
        {
            InProgress,   
            BetweenQuestions,
            Completed        
        }

        /// <summary>
        /// Represents the live state of a quiz session, used for state recovery (e.g., on page refresh).
        /// </summary>
        public class QuizStateDto
        {
            public LiveQuizStatus Status { get; set; }

            /// <summary>
            /// If the status is InProgress, this will contain the details of the active question.
            /// Will be null otherwise.
            /// </summary>
            public CurrentQuestionDto? ActiveQuestion { get; set; }
        }

        /// <summary>
        /// The result of resolving and resuming a quiz session.
        /// Contains the resolved state after auto-timing-out any expired questions.
        /// </summary>
        public class ResumeResultDto
        {
            public QuizSessionDto Session { get; set; } = null!;

            /// <summary>
            /// The question the user should resume on. Null if the quiz is complete.
            /// </summary>
            public CurrentQuestionDto? ActiveQuestion { get; set; }

            /// <summary>
            /// The 1-based question number the user is on (e.g., 3 = third question).
            /// </summary>
            public int QuestionNumber { get; set; }

            /// <summary>
            /// True if all remaining questions timed out and the quiz auto-completed.
            /// </summary>
            public bool IsQuizComplete { get; set; }

            /// <summary>
            /// How many questions were auto-marked as TimedOut during the catch-up.
            /// </summary>
            public int SkippedCount { get; set; }
        }

    public class QuizSessionCM
        {
            public int QuizId { get; set; }
            public Guid UserId { get; set; }

            /// <summary>
            /// Required to start a session for an Unlisted quiz you don't own — it's the access grant
            /// from the share link. Ignored for Public quizzes and for quizzes you own.
            /// </summary>
            public string? ShareToken { get; set; }
        }

        public class GuestQuizSessionCM
        {
            public int QuizId { get; set; }
        }

        public class ResumeRequestDto
        {
            public Guid UserId { get; set; }
        }

        public class UserAnswerCM
        {
            public Guid SessionId { get; set; }
            public int QuizQuestionId { get; set; }
            public int? SelectedOptionId { get; set; }
            public string? SubmittedAnswer { get; set; }
            /// <summary>
            /// Set to true by the frontend when the client-side timer expired.
            /// The backend uses this alongside its own server-side clock check
            /// to reliably determine timeouts regardless of network latency.
            /// </summary>
            public bool IsTimedOut { get; set; } = false;

            /// <summary>
            /// Client-measured think time in milliseconds: question rendered → answer submitted,
            /// taken from a monotonic clock (<c>performance.now()</c>). Used only for SCORING —
            /// after server-side validation against the server's own window (see
            /// <c>Services/Scoring/QuizTiming</c>) — so a player's ping doesn't eat their speed
            /// bonus. Timeout enforcement never trusts this value. Null (older clients) means
            /// scoring falls back to the server-measured window.
            /// </summary>
            public long? ClientElapsedMs { get; set; }
        }

        // Data Transfer Objects
        public class QuizSessionDto
        {
            public Guid Id { get; set; }
            public int QuizId { get; set; }
            public string QuizTitle { get; set; } = string.Empty;
            public Guid UserId { get; set; }
            public DateTime StartTime { get; set; }
            public DateTime? EndTime { get; set; }
            public int TotalScore { get; set; }
            public bool IsCompleted { get; set; }
            public List<UserAnswerDto> UserAnswers { get; set; } = new();
            public AbandonmentReason? AbandonmentReason { get; set; }
            public DateTime? AbandonedAt { get; set; }

            public bool HasInstantFeedback { get; set; }
            public int TotalQuestions { get; set; }
            public string? QuizDescription { get; set; }
            public string? Category{ get; set; }
    }

        public class UserAnswerDto
        {
        public int Id { get; set; }
        public AnswerStatus Status { get; set; }
        public int Score { get; set; }

        public int? SelectedOptionId { get; set; } // For MC/T-F questions
        public string? SubmittedAnswer { get; set; }

        // --- Question Context ---
        public string QuestionText { get; set; } = string.Empty;
        public string? MediaUrl { get; set; }
        public string MediaType { get; set; } = "None";
        [JsonConverter(typeof(JsonStringEnumConverter))] // Ensures the enum is sent as a string
        public QuestionType QuestionType { get; set; }
        public int TimeLimitInSeconds { get; set; }
        public double? TimeSpentInSeconds { get; set; } // Calculated field

        /// <summary>
        /// For MultipleChoice questions: A list of all available options, including correctness.
        /// </summary>
        public List<AnswerOptionDTO>? AnswerOptions { get; set; }

        /// <summary>
        /// For TrueFalse questions: The correct boolean answer.
        /// </summary>
        public bool? CorrectAnswerBoolean { get; set; }

        /// <summary>
        /// For TypeTheAnswer questions: The primary correct answer string.
        /// </summary>
        public string? CorrectAnswerText { get; set; }

        /// <summary>
        /// For TypeTheAnswer questions: A list of all other acceptable answers.
        /// </summary>
        public List<string>? AcceptableAnswers { get; set; }
    }

    public class CurrentQuestionDto
    {
        
        public int QuizQuestionId { get; set; }
        public string QuestionText { get; set; } = string.Empty;
        public string? MediaUrl { get; set; }
        public string MediaType { get; set; } = "None";
        public List<AnswerOptionForQuizPlaying> Options { get; set; } = new();
        public int TimeLimitInSeconds { get; set; }
        public int TimeRemainingInSeconds { get; set; }
        public required string QuestionType { get; set; }

        /// <summary>
        /// True for multiple-choice questions that accept more than one correct option.
        /// The client renders checkboxes + a "select all that apply" hint and submits the
        /// chosen option ids as a comma-separated list in <c>SubmittedAnswer</c>.
        /// </summary>
        public bool AllowMultipleSelections { get; set; }
    }

    public class QuizSessionSummaryDto
        {
            public Guid Id { get; set; }
            public int QuizId { get; set; }
            public string QuizTitle { get; set; } = string.Empty;
            public DateTime StartTime { get; set; }
            public DateTime? EndTime { get; set; }
            public int TotalScore { get; set; }
            public int TotalQuestions { get; set; }
            public int CorrectAnswers { get; set; }
            public bool IsCompleted { get; set; }
            public TimeSpan? Duration { get; set; }
            public AbandonmentReason? AbandonmentReason { get; set; }
            public DateTime? AbandonedAt { get; set; }
    }

    public class AnswerResultDto
    {
        /// <summary>
        /// The outcome of the answer submission (e.g., Correct, Incorrect, TimedOut).
        /// </summary>
        public AnswerStatus Status { get; set; }

        /// <summary>
        /// The score awarded for this specific answer. Will be 0 if incorrect or timed out.
        /// </summary>
        public int ScoreAwarded { get; set; }

        /// <summary>
        /// A flag indicating whether this was the last question in the quiz.
        /// The client uses this to know whether to enable a "Next Question" button
        /// or navigate to the final results screen.
        /// </summary>
        public bool IsQuizComplete { get; set; }
    }

    public class InstantFeedbackAnswerResultDto
    {
        /// <summary>
        /// The outcome of the answer submission (e.g., Correct, Incorrect, TimedOut).
        /// </summary>
        public AnswerStatus Status { get; set; }

        /// <summary>
        /// The score awarded for this specific answer. Will be 0 if incorrect or timed out.
        /// </summary>
        public int ScoreAwarded { get; set; }

        /// <summary>
        /// A flag indicating whether this was the last question in the quiz.
        /// </summary>
        public bool IsQuizComplete { get; set; }

        /// <summary>
        /// For Multiple Choice questions: The ID of the correct option.
        /// Only provided when instant feedback is enabled and answer was incorrect/timed out.
        /// </summary>
        public int? CorrectOptionId { get; set; }

        /// <summary>
        /// For True/False questions: The correct answer ("True" or "False").
        /// For TypeTheAnswer questions: The primary correct answer.
        /// Only provided when instant feedback is enabled and answer was incorrect/timed out.
        /// </summary>
        public string? CorrectAnswer { get; set; }

        /// <summary>
        /// For TypeTheAnswer questions: Alternative acceptable answers.
        /// Only provided when instant feedback is enabled and answer was incorrect/timed out.
        /// </summary>
        public List<string>? AcceptableAnswers { get; set; }

        /// <summary>
        /// For multiple-choice questions that allow multiple selections: the full set of correct
        /// option ids (so the client can highlight every correct option). For single-answer
        /// questions <see cref="CorrectOptionId"/> is used instead.
        /// </summary>
        public List<int>? CorrectOptionIds { get; set; }

        /// <summary>
        /// Time spent on the question in seconds.
        /// </summary>
        public double TimeSpentInSeconds { get; set; }
    }

}
