import { useState, type ReactNode } from "react";
import { useNavigate } from "react-router-dom";
import { ArrowLeft, Bot, FileText, Wand2 } from "lucide-react";

import { LiftedButton } from "@/common/LiftedButton";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { cn } from "@/utils/cn";

/**
 * Whether "from my material" can be picked yet.
 *
 * The server already accepts pasted `sourceText`, but the mode users actually asked for is
 * *upload a file* — slice 2.3 in docs/quiz/ai-quiz-generation-flow.md. Until that lands the
 * row renders disabled with a "Soon" chip: showing it settles the shape of the choice now,
 * so enabling it later doesn't move the other two options under anyone's cursor.
 *
 * Flipping this to `true` takes three steps, and they only work together:
 *   1. this constant,
 *   2. register `quizzes/create-quiz/ai/material` (and the `/my-dashboard` twin) in
 *      `routes/Router.tsx` — `useAiQuizDraft` already reads the mode off that segment,
 *   3. nothing in the wizard: it renders whichever field the route's mode asks for.
 */
export const AI_MATERIAL_MODE_ENABLED = false;

type Step = "method" | "aiSource";

export interface CreateQuizMethodDialogProps {
  /** Route for the hand-authored builder, e.g. `/dashboard/quizzes/create-quiz`. */
  manualPath: string;
  /** The generate-for-me wizard in topic mode, e.g. `/dashboard/quizzes/create-quiz/ai/topic`. */
  aiTopicPath: string;
  /** The bring-your-own-AI page, e.g. `/dashboard/quizzes/create-quiz/ai/own`. */
  aiOwnPath: string;
  /**
   * What opens the dialog. Defaults to the standard "+ Create Quiz" button; pass your own
   * if a surface needs different affordance (it's wrapped in `DialogTrigger asChild`).
   */
  trigger?: ReactNode;
  /**
   * Controlled open state. Leave both undefined for the normal trigger-driven behaviour —
   * Radix treats `open === undefined` as uncontrolled. Stories pass `open` to pin the
   * dialog in view without simulating a click.
   */
  open?: boolean;
  onOpenChange?: (open: boolean) => void;
  /**
   * Which step to start on. Initial value only — the dialog resets to `"method"` whenever it
   * opens. Exists so a story can pin the second step without scripting a click.
   */
  initialStep?: Step;
}

/**
 * One row of the "what should the AI work from?" step.
 *
 * A stacked row rather than a button in a grid: each option needs a sentence under its label,
 * and three fixed-padding controls side by side deform instead of wrapping at around 500px
 * (docs/RESPONSIVE.md, "Rows of buttons"). Same shape as the question-type rows in the
 * Advanced drawer, for the same reason — full-width targets that read as a list of choices.
 */
const SourceOption = ({
  icon: Icon,
  label,
  description,
  badge,
  disabled,
  onClick,
}: {
  icon: typeof Wand2;
  label: string;
  description: string;
  badge?: string;
  disabled?: boolean;
  onClick?: () => void;
}) => (
  <button
    type="button"
    disabled={disabled}
    onClick={onClick}
    className={cn(
      // min-h-11 (44px): docs/RESPONSIVE.md wants 40–44px for the choices that matter, and
      // on this screen every one of them matters.
      "flex min-h-11 w-full items-start gap-3 rounded-lg border-2 px-3 py-3 text-left transition-colors",
      "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background",
      disabled
        ? "cursor-not-allowed border-border/60 opacity-60"
        : "border-border hover:border-primary hover:bg-primary/5"
    )}
  >
    <Icon className="mt-0.5 h-4 w-4 shrink-0 text-primary" aria-hidden />
    <span className="min-w-0 flex-1">
      <span className="flex flex-wrap items-center gap-2">
        <span className="text-sm font-semibold leading-tight text-foreground">
          {label}
        </span>
        {badge && (
          <span className="shrink-0 rounded-full border border-primary/20 bg-primary/10 px-2 py-0.5 text-[11px] font-medium text-primary">
            {badge}
          </span>
        )}
      </span>
      <span className="mt-0.5 block text-xs leading-snug text-muted-foreground">
        {description}
      </span>
    </span>
  </button>
);

/**
 * The fork in the road for quiz creation, in two steps.
 *
 * **Step 1** is the one that was always here: build it by hand, or with an AI.
 * **Step 2** appears only for people who chose AI, and asks the question the wizard used to
 * ask with a tab strip welded to the top of its card — where should the AI get its material?
 *
 * Moving it here is what lets the wizard be a form again. The card used to carry four
 * separate "which way?" controls (the mode tabs, Advanced, and two grey footer links) wrapped
 * around a single text box; now every route decision is made once, before anything is typed,
 * and the page you land on has one field, one Advanced drawer and one button. The chosen mode
 * travels in the URL, so the wizard never needs the tabs back — see
 * docs/quiz/ai-quiz-two-paths.md.
 *
 * Two steps in one overlay rather than a second dialog or a chooser page: the user already
 * has this dialog open, and swapping its body is a cheaper transition than closing it to load
 * a route for one binary decision. The cost is that browser Back doesn't undo step 2, which
 * is what the arrow next to the title is for.
 *
 * Presentational and route-agnostic on purpose. The two dashboards mount the same quiz flows
 * under different path prefixes (`/dashboard/quizzes/create-quiz` vs.
 * `/my-dashboard/quizzes/create`), so the paths are props rather than hard-coded — a
 * copy-pasted version of this dialog is how one surface ends up linking into the other
 * dashboard's routes.
 */
export const CreateQuizMethodDialog = ({
  manualPath,
  aiTopicPath,
  aiOwnPath,
  trigger,
  open,
  onOpenChange,
  initialStep = "method",
}: CreateQuizMethodDialogProps) => {
  const navigate = useNavigate();
  const [step, setStep] = useState<Step>(initialStep);

  /**
   * Reset on *open*, not on close. Resetting as it closes swaps the body back to step 1
   * mid-animation, so the user watches their own choice get undone on the way out.
   */
  const handleOpenChange = (next: boolean) => {
    if (next) setStep("method");
    onOpenChange?.(next);
  };

  const isMethodStep = step === "method";

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogTrigger asChild>
        {trigger ?? <LiftedButton>+ Create Quiz</LiftedButton>}
      </DialogTrigger>
      {/* DialogContent owns the phone gutter and the height cap itself — see
          docs/RESPONSIVE.md. Both steps are short, so one width suits them. */}
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          {/* pr-6 clears the close button; the back arrow sits inline with the title rather
              than above it, so the header keeps one line at phone widths. */}
          <DialogTitle className="flex items-center gap-2 pr-6 text-xl">
            {!isMethodStep && (
              <button
                type="button"
                onClick={() => setStep("method")}
                aria-label="Back to how you want to build this quiz"
                className="-ml-1 shrink-0 rounded-md p-1 text-muted-foreground transition-colors hover:bg-muted hover:text-foreground"
              >
                <ArrowLeft className="h-4 w-4" />
              </button>
            )}
            {isMethodStep
              ? "How do you want to build this quiz?"
              : "What should the AI work from?"}
          </DialogTitle>
        </DialogHeader>

        {isMethodStep ? (
          /* Grid, not a flex row: equal columns give both buttons one width, and stacking
             below `sm` is a layout change rather than a squeezed, mid-phrase-wrapping
             deformation. See "Rows of buttons" in docs/RESPONSIVE.md.

             `outerClassName="w-full"` sizes the outer button to the grid cell and
             `h-full w-full` makes the front face fill it, so a label that wraps on one
             button can't leave the other's coloured face short in an equal-height row. */
          <div className="mt-2 grid grid-cols-1 gap-3 sm:grid-cols-2">
            {/* Green marks the hand-authored path so the two options are distinguishable at
                a glance. `liftColor` recolors the edge and drop shadow to match: leave it
                out and a green face sits on the theme-primary blue depth layers. Both read
                from the same `--quiz-success` token, so dark mode tracks automatically. */}
            <LiftedButton
              type="button"
              onClick={() => navigate(manualPath)}
              outerClassName="w-full"
              liftColor="hsl(var(--quiz-success))"
              className="h-full w-full bg-quiz-success px-4 py-2.5 text-center text-sm font-semibold leading-tight"
            >
              Create manually
            </LiftedButton>

            {/* Advances the dialog instead of navigating — the AI branch has one more
                question, and it is the question the wizard should no longer be asking. */}
            <LiftedButton
              type="button"
              onClick={() => setStep("aiSource")}
              outerClassName="w-full"
              className="h-full w-full px-4 py-2.5 text-center text-sm font-semibold leading-tight"
            >
              Create with AI
            </LiftedButton>
          </div>
        ) : (
          <div className="mt-2 flex flex-col gap-2">
            <SourceOption
              icon={Wand2}
              label="From a topic"
              description="Name a subject and we'll write the questions. Uses one of your daily generations."
              onClick={() => navigate(aiTopicPath)}
            />

            <SourceOption
              icon={FileText}
              label="From my material"
              description="Build questions out of your own notes, article or transcript."
              badge="Soon"
              disabled={!AI_MATERIAL_MODE_ENABLED}
            />

            {/* A peer, not a footnote. This used to be a grey link at the bottom of the
                wizard card — the one place nobody looks — even though it is the option that
                costs nothing and keeps working when the daily quota is spent. */}
            <SourceOption
              icon={Bot}
              label="I'll use my own AI"
              description="Copy a prompt into ChatGPT, Claude or Gemini and paste the reply back. Free, no quota."
              onClick={() => navigate(aiOwnPath)}
            />
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};

export default CreateQuizMethodDialog;
