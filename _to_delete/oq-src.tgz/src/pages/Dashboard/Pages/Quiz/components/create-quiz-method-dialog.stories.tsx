import type { Meta, StoryObj } from "@storybook/react";
import { fn } from "@storybook/test";
import { MemoryRouter } from "react-router-dom";
import { CreateQuizMethodDialog } from "./create-quiz-method-dialog";

/**
 * The fork users hit when they click "+ Create Quiz", in two steps: build it by hand or with
 * an AI, and then — for the AI branch — what the AI should work from.
 *
 * Step 2 is the wizard's old tab strip, moved. Every "which way?" decision for quiz creation
 * is made here now, which is what lets the wizard page be a form with one field instead of a
 * card wrapped in four navigational controls. See docs/quiz/ai-quiz-two-paths.md.
 *
 * MemoryRouter decorator: the options navigate with `useNavigate`, which throws outside a
 * router. Same pattern as Not-Found-Content.stories.tsx. Clicking one in a story navigates
 * the in-memory history, so nothing appears to happen — that's expected; the targets are
 * visible in the Controls panel. Clicking "Create with AI", by contrast, *does* visibly do
 * something: it advances to step 2.
 *
 * The manual option is green and the AI one theme-primary; `liftColor` keeps each button's
 * edge and shadow in its own hue. Check both themes — the greens come from
 * `--quiz-success`, which has a separate dark-mode value.
 */
const meta = {
  title: "Dashboard/Quiz/CreateQuizMethodDialog",
  component: CreateQuizMethodDialog,
  parameters: { layout: "centered" },
  decorators: [
    (Story) => (
      <MemoryRouter>
        <Story />
      </MemoryRouter>
    ),
  ],
  args: {
    manualPath: "/dashboard/quizzes/create-quiz",
    aiTopicPath: "/dashboard/quizzes/create-quiz/ai/topic",
    aiOwnPath: "/dashboard/quizzes/create-quiz/ai/own",
    onOpenChange: fn(),
  },
} satisfies Meta<typeof CreateQuizMethodDialog>;

export default meta;
type Story = StoryObj<typeof meta>;

/** As it sits on the Quiz Management page — just the trigger until someone clicks it. */
export const ClosedWithTrigger: Story = {
  args: { open: false },
};

/** Step 1: the decision that was always here. Pinned open so it can be reviewed directly. */
export const Open: Story = {
  args: { open: true },
};

/**
 * Step 2, reached by pressing "Create with AI" — pinned via `initialStep` so it can be
 * reviewed without scripting a click.
 *
 * Three stacked rows rather than a three-across grid: each carries a sentence, and three
 * fixed-padding controls in a row deform rather than wrap at awkward in-between widths
 * (docs/RESPONSIVE.md, "Rows of buttons").
 *
 * "From my material" is disabled behind `AI_MATERIAL_MODE_ENABLED` — the server takes pasted
 * text today, but the mode users asked for is file upload (slice 2.3). Showing it now settles
 * the shape of the choice, so enabling it later doesn't move the other two rows under
 * anyone's cursor.
 */
export const AiSourceStep: Story = {
  args: { open: true, initialStep: "aiSource" },
};

/**
 * The user dashboard mounts the same flows under different paths
 * (`/my-dashboard/quizzes/create…`). Nothing about the dialog changes — this story exists
 * to show the component is route-agnostic, which is what stops a second copy of it from
 * being written for the other dashboard.
 */
export const OpenForUserDashboard: Story = {
  args: {
    open: true,
    manualPath: "/my-dashboard/quizzes/create",
    aiTopicPath: "/my-dashboard/quizzes/create/ai/topic",
    aiOwnPath: "/my-dashboard/quizzes/create/ai/own",
  },
};

/**
 * Phone width: step 1's two options stack (`grid-cols-1 sm:grid-cols-2`) and the dialog keeps
 * a 1rem gutter each side — the shared DialogContent owns that now, see docs/RESPONSIVE.md.
 */
export const OpenOnMobile: Story = {
  parameters: { viewport: { defaultViewport: "mobile1" } },
  args: { open: true },
};

/**
 * Step 2 at phone width. The rows are already full-width at every breakpoint, so the thing
 * to check here is that the two-line descriptions don't push the dialog past its height cap
 * and that the back arrow stays on the title's line.
 */
export const AiSourceStepOnMobile: Story = {
  parameters: { viewport: { defaultViewport: "mobile1" } },
  args: { open: true, initialStep: "aiSource" },
};
